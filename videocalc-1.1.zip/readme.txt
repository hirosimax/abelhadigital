VideoCalc 1.1
� 1997-2005 abelhadigital.com


Information:
- This program calculates the bitrate to use when encoding a movie to DVD/SVCD/DivX
  formats. Remember that the final file size might be different of the one you have
  specified, especially when encoding a movie using variable bitrate mode (VBR).

Installation:
- Just extract the files to any folder of your choice.

License:
- Read license.txt.

Warranty:
- We take no responsibility for any kind of loss or damage caused by the usage of this
  program. Use it at your own risk!


Contact:
- Website: http://videocalc.abelhadigital.com/
- Email: info@abelhadigital.com