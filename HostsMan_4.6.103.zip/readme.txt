HostsMan 4.6.103
� 1997-2015 abelhadigital.com

Website: http://www.abelhadigital.com/
Forum  : http://forum.abelhadigital.com/
Email  : info@abelhadigital.com

Portions of this software are Copyright (c) 1999-2006 Mike Lischke, All rights
reserved. - http://www.delphi-gems.com/
Portions of this software are Copyright (c) 2008, Primoz Gabrijelcic

SUPPORTED OPERATING SYSTEMS:
----------------------------

     Microsoft Windows XP SP2 or later
     Microsoft Windows Server 2003 SP1 or Later
     Microsoft Windows Vista
     Microsoft Windows Server 2008
     Microsoft Windows 7
     Microsoft Windows Server 2008 R2
	 Microsoft Windows 8
     Microsoft Windows Server 2012
	 Microsoft Windows 8.1
     Microsoft Windows Server 2012 R2
	 Microsoft Windows 10


KNOWN ISSUES:
-----------------

	 - Documentation is incomplete


LEGAL DISCLAIMER:
-----------------

     Please read license.txt.
